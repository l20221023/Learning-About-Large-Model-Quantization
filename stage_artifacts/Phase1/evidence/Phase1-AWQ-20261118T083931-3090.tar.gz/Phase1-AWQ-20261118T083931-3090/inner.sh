#!/usr/bin/env bash
set -euo pipefail
export VLLM_USE_FLASHINFER_SAMPLER=0
export PATH="$WORK/venv-vllm-0.26.0/bin:$PATH"
nvidia-smi --query-gpu=timestamp,memory.used,utilization.gpu --format=csv,noheader,nounits -lms 250 > "$OUT/gpu.csv" 2>&1 &
monitor=$!
"$VLLM" serve "$SNAPSHOT" --served-model-name p2-awq --host 127.0.0.1 --port 8765 \
  --max-model-len 256 --max-num-batched-tokens 256 --max-num-seqs 1 \
  --kv-cache-memory-bytes 536870912 --no-enable-prefix-caching --enforce-eager > "$OUT/server.log" 2>&1 &
server=$!
cleanup() { kill "$server" "$monitor" 2>/dev/null || true; wait "$server" "$monitor" 2>/dev/null || true; }
trap cleanup EXIT INT TERM
ready=0
for _ in $(seq 1 120); do
  if ! kill -0 "$server" 2>/dev/null; then echo 'server exited before health check' >&2; exit 1; fi
  if curl --fail --silent --max-time 2 http://127.0.0.1:8765/health >/dev/null; then ready=1; break; fi
  sleep 2
done
[[ $ready == 1 ]] || { echo 'server health timeout' >&2; exit 1; }
"$PY" "$HERE/collect_awq_baseline.py" --workload "$HERE/m0_4_seed_prompts.json" --output "$OUT/raw.jsonl" > "$OUT/collect.log" 2>&1
"$PY" "$HERE/analyze_awq_baseline.py" "$OUT/raw.jsonl" --output "$OUT/summary.json" > "$OUT/analyze.log" 2>&1
